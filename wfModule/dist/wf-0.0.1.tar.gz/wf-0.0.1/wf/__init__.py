#!/usr/bin/env python
'''
NAME
   myscript - calculate a frequenc of a word in a document

SYNOPSIS
   word_frequency [options] input_file
   options:
        -m 20 : shows 20 more common, alfabetically
        -n : Order alfabetically

Description

'''

__version__ = "0.0.1"

import sys
import re
from collections import Counter
from jjcli import * 


def tokenize(text):
    words = re.findall(r'\w+(?:\-\w+)?|[,;./\-\(\)!?""\—]+', text)
    return words

def imprime(lst):
    for e, n_occ in lst:
        print(f"{e}\t{n_occ}")


def normaliza(dic):
    for k,v in dic:
        if k[0] >= 'A' and k[0] <='Z':
            lower = k.lower()
            if lower in dic:
                dic[lower] = dic[lower] + v
                dic.pop(k)

    return dic

def main():
    
    cl=clfilter("nm:", doc=__doc__)     ## option values in cl.opt dictionary
    
    
    for txt in cl.text():     ## process one file at the time
        prep_t = tokenize(txt)

        if "-m" in cl.opt:
            imprime(frequency.most_common(int(cl.opt.get("-m")) ))
        elif "-n" in cl.opt:
            prep_t.sort()
            frequency = Counter(prep_t)
            imprime(frequency.items())
        elif "-c" in cl.opt:
            freqNormalizado = normaliza(prep_t)
            frequency = Counter(freqNormalizado)
            imprime(frequency.items())
            
        else:
            pass


